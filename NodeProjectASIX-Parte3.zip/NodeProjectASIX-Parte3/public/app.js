
const btn = document.getElementById("btn");
const btnToXML = document.getElementById("btnToXML");

const btnXmlToJson = document.getElementById("btnXmlToJson");
const btnJsonToXml = document.getElementById("btnJsonToXml");

const btnPokeXml = document.getElementById("btnPokeXml");
const btnPokeInfo = document.getElementById("btnPokeInfo");

btn.addEventListener("click", async () => {

  const text = document.getElementById("input").value;

  // Fem una petició HTTP al servidor (Express)
  // fetch() envia una request al backend
  const res = await fetch("/convert", {
    // Tipus de petició
    // POST = enviem dades al servidor
    method: "POST",
    // Capçaleres HTTP
    // Indiquem que estem enviant dades en format JSON
    headers: {
      "Content-Type": "application/json"
    },

    // Cos de la petició (les dades que enviem)
    // Convertim l’objecte JS a text JSON
    body: JSON.stringify({ data: text })
  });

  // El servidor respon amb JSON
  // Convertim la resposta a objecte JavaScript
  const json = await res.json();
  
  // Mostrem el resultat a la textarea de sortida
  document.getElementById("output").value = json.result;
});

btnToXML.addEventListener("click", async () => {

  const text = document.getElementById("input").value;

  // Fem una petició HTTP al servidor (Express)
  // fetch() envia una request al backend
  const res = await fetch("/convertTOXMl", {
    // Tipus de petició
    // POST = enviem dades al servidor
    method: "POST",
    // Capçaleres HTTP
    // Indiquem que estem enviant dades en format JSON
    headers: {
      "Content-Type": "application/json"
    },

    // Cos de la petició (les dades que enviem)
    // Convertim l’objecte JS a text JSON
    body: JSON.stringify({ data: text })
  });

  // El servidor respon amb JSON
  // Convertim la resposta a objecte JavaScript
  const json = await res.json();
  
  // Mostrem el resultat a la textarea de sortida
  document.getElementById("output").value = json.result;
});

btnXmlToJson.addEventListener("click", async () => {

  const text = document.getElementById("input").value;

  const res = await fetch("/xml-to-json", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ data: text })
  });

  const json = await res.json();
  
  document.getElementById("output").value = json.result;
});

btnJsonToXml.addEventListener("click", async () => {

  const text = document.getElementById("input").value;

  const res = await fetch("/json-to-xml", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ data: text })
  });

  const json = await res.json();
  
  document.getElementById("output").value = json.result;
});

btnPokeXml.addEventListener("click", async () => {

  const text = document.getElementById("input").value;

  if (!text || text.trim() === "") {
    alert("Per favor, escriu el nom d'un Pokémon");
    return;
  }

  try {
    const res = await fetch("/pokemon-xml", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ data: text })
    });

    const json = await res.json();
    
    if (json.error) {
      alert(json.error);
    } else {
      document.getElementById("output").value = json.result;
    }
  } catch (error) {
    alert("Error: " + error.message);
  }
});

btnPokeInfo.addEventListener("click", async () => {

  const text = document.getElementById("input").value;

  if (!text || text.trim() === "") {
    alert("Per favor, escriu el nom d'un Pokémon");
    return;
  }

  try {
    const res = await fetch("/pokemon-data", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ data: text })
    });

    const pokemon = await res.json();
    
    if (pokemon.error) {
      alert(pokemon.error);
      return;
    }

    // Limpiar el contenedor anterior
    const container = document.getElementById("pokemon-container");
    container.innerHTML = "";

    // Crear la imatge dinàmicament
    if (pokemon.sprites && pokemon.sprites.front_default) {
      const img = document.createElement("img");
      img.src = pokemon.sprites.front_default;
      img.alt = pokemon.name;
      img.style.width = "150px";
      container.appendChild(img);
    }

    // Crear un paràgraf per mostrar el nom
    const nameP = document.createElement("p");
    nameP.textContent = "Nom: " + (pokemon.name || "No disponible");
    container.appendChild(nameP);

    // Extreure i mostrar les habilitats
    if (pokemon.abilities && pokemon.abilities.length > 0) {
      const abilitiesTitle = document.createElement("p");
      abilitiesTitle.textContent = "Habilitats:";
      abilitiesTitle.style.fontWeight = "bold";
      container.appendChild(abilitiesTitle);

      const abilitiesList = document.createElement("ul");
      pokemon.abilities.forEach(ability => {
        const li = document.createElement("li");
        li.textContent = ability.ability.name;
        abilitiesList.appendChild(li);
      });
      container.appendChild(abilitiesList);
    }

  } catch (error) {
    alert("Error: " + error.message);
  }
});