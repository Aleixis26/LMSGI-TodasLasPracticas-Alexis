const express = require("express");
const convert = require("xml-js");

const app = express();
const PORT = 3000;

// permet rebre JSON
app.use(express.json());

// servir fitxers estàtics (HTML, JS, CSS)
app.use(express.static("public"));

// endpoint d'exemple
app.post("/convert", (req, res) => {
  const { data } = req.body;
  const result = data.toUpperCase(); 
  res.json({ result });
});

//=================funció manual corregida===========================================
app.post("/convertTOXMl", (req, res) => {
  const { data } = req.body;
  let textRebut = data; 

  // 1. Limpieza del string
  textRebut = textRebut.replace("{", "");
  textRebut = textRebut.replace("}", "");
  textRebut = textRebut.replace(/"/g, "");

  // 2. Crear los arrays keys y values
  let keyvalues = textRebut.split(",");
  let keys = [];
  let values = [];

  for (let i = 0; i < keyvalues.length; i++) {
    let temp = keyvalues[i].split(":");
    if (temp.length === 2) { // Verificación simple de formato
      keys.push(temp[0].trim());
      values.push(temp[1].trim());
    }
  }

  // 3. Construcción del XML
  let xml = "<arrel>";
  for (let i = 0; i < keys.length; i++) {
    xml += "<" + keys[i] + ">";     // Obertura
    xml += values[i];               // Contingut
    xml += "</" + keys[i] + ">";    // Tancament
  }
  xml += "</arrel>";

  res.json({ result: xml });
});

//=================Funcions amb LLIBRERIA===========================================

app.post("/xml-to-json", (req, res) => {
  const { data } = req.body;
  const result = convert.xml2json(data, {compact: true, spaces: 4});
  res.json({ result });
});

app.post("/json-to-xml", (req, res) => {
  const { data } = req.body;
  // Intentamos parsear a objeto para que la librería funcione mejor
  try {
    const obj = JSON.parse(data);
    const result = convert.js2xml(obj, {compact: true, spaces: 4});
    res.json({ result });
  } catch(e) {
    // Si no es un JSON válido, lo intentamos como texto plano
    const result = convert.json2xml(data, {compact: true, spaces: 4});
    res.json({ result });
  }
});

//=================Rutes de PokeAPI===========================================

app.post("/pokemon-xml", async (req, res) => {
  const { data } = req.body;
  if (!data || data.trim() === "") {
    return res.status(400).json({ error: "Nom del Pokémon no pot estar buit" });
  }
  const pokemonName = data.trim().toLowerCase();
  const pokemonUrl = `https://pokeapi.co/api/v2/pokemon/${pokemonName}`;

  try {
    const response = await fetch(pokemonUrl);
    if (!response.ok) return res.status(404).json({ error: "Pokémon no trobat" });
    
    const pokemonData = await response.json();
    const result = convert.json2xml(JSON.stringify(pokemonData), {compact: true, spaces: 4});
    res.json({ result });
  } catch (error) {
    res.status(500).json({ error: "Error en la cerca" });
  }
});

app.post("/pokemon-data", async (req, res) => {
  const { data } = req.body;
  if (!data || data.trim() === "") {
    return res.status(400).json({ error: "Nom del Pokémon no pot estar buit" });
  }
  const pokemonName = data.trim().toLowerCase();
  const pokemonUrl = `https://pokeapi.co/api/v2/pokemon/${pokemonName}`;

  try {
    const response = await fetch(pokemonUrl);
    if (!response.ok) return res.status(404).json({ error: "Pokémon no trobat" });
    
    const pokemonData = await response.json();
    res.json(pokemonData);
  } catch (error) {
    res.status(500).json({ error: "Error en la cerca" });
  }
});

app.listen(PORT, () => {
  console.log(`Servidor a http://localhost:${PORT}`);
});