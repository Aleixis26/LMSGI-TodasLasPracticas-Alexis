const express = require("express");
const convert = require("xml-js");

const app = express();
const PORT = 3000;

// permet rebre JSON
app.use(express.json());

// servir fitxers estàtics (HTML, JS, CSS)
app.use(express.static("public"));


// endpoint d'exemple
app.post("/convert", (req, res) => {
  const { data } = req.body;

  const result = data.toUpperCase(); // prova simple
  res.json({ result });
});

//=================funció a completar===========================================
app.post("/convertTOXMl", (req, res) => {
  const { data } = req.body;
   let textRebut='{"key1":value1,"key2":value2,""key3":value3}'; 
   //a data esperem un text similar al de dalt
   textRebut = data; //guardem el text real que envia el usuari 
   // com el json que rebrem es de tipus simple, sense objectes ni llistes netejerem l'string per treballar millor.
   textRebut= textRebut.replace("{",""); //eliminem del string la clau d'obertura
   textRebut= textRebut.replace("}",""); //eliminem del string la clau de tancament
   textRebut = textRebut.replace(/"/g, ""); //eliminem del string tots els ""
   
   //key1:value1,key2:value2,key3:value3  us pudeo imaginar un resultat com aquest

   //Sabem que per cada key del json haurem de crear una etiqueta i aquesta tindra com a contingut el value


   let keyvalues =[];//declarem una llista buida
   keyvalues = textRebut.split(",");// si ha un string  li apliquem split, guardem una llista de elements separats per el carcter
   let keys=[]; //aqui guardarem les keys després
   let values =[]; // i aquí els values
   for(let i=0; i < keyvalues.length;i++) //aquest for permet un bucle que recorre tots els keyvalues
    {
       let temp= keyvalues[i].split(":") // separem el string en dos parts per el :
       keys.push(temp[0]);// la primera part(la 0) sera la key i la afegim  a la llista de keys.
       values.push(temp[1]);// la segona part sera el value i la afegim a la llista de values.
    }

   let xml="";//declarem un string
   xml +="<arrel>";//afegim al string un tros de text
   //
   for(let i =0;i<keys.length;i++)
    {
        //ara en aquest bucle hauras de afegir els trossos que fan falta a l'xml per passar l'informació.

        //pista keys[i] accedeix a la llista de keys i posa el text que hem guardat abans, el mateix amb values[i]
        xml+="<";
        //continua per aquí!
      }
    xml +="</arrel>";
    console.log(xml);
    result = xml;

  res.json({ result });
});

app.post("/xml-to-json", (req, res) => {
  const { data } = req.body;

  const result = convert.xml2json(data, {compact: true, spaces: 4});
  res.json({ result });
});

app.post("/json-to-xml", (req, res) => {
  const { data } = req.body;

  const result = convert.json2xml(data, {compact: true, spaces: 4});
  res.json({ result });
});

app.listen(PORT, () => {
  console.log(`Servidor a http://localhost:${PORT}`);
});
