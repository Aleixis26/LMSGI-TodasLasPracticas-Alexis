
const inputElement = document.getElementById("input");
const outputElement = document.getElementById("output");
const pokemonContainer = document.getElementById("pokemon-container");

const btn = document.getElementById("btn");
const btnToXML = document.getElementById("btnToXML");
const btnXmlToJson = document.getElementById("btnXmlToJson");
const btnJsonToXml = document.getElementById("btnJsonToXml");
const btnPokeXml = document.getElementById("btnPokeXml");
const btnPokeInfo = document.getElementById("btnPokeInfo");

async function postData(url, text) {
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ data: text })
  });

  const json = await response.json();

  if (!response.ok) {
    throw new Error(json.error || "Error de servidor");
  }

  return json;
}

btn.addEventListener("click", async () => {
  const text = inputElement.value;
  const json = await postData("/convert", text);
  outputElement.value = json.result;
});

btnToXML.addEventListener("click", async () => {
  const text = inputElement.value;
  const json = await postData("/convertTOXMl", text);
  outputElement.value = json.result;
});

btnXmlToJson.addEventListener("click", async () => {
  const text = inputElement.value;
  try {
    const json = await postData("/xml-to-json", text);
    outputElement.value = json.result;
  } catch (error) {
    alert(error.message);
  }
});

btnJsonToXml.addEventListener("click", async () => {
  const text = inputElement.value;
  try {
    const json = await postData("/json-to-xml", text);
    outputElement.value = json.result;
  } catch (error) {
    alert(error.message);
  }
});

btnPokeXml.addEventListener("click", async () => {
  const text = inputElement.value;

  if (!text || text.trim() === "") {
    alert("Per favor, escriu el nom d'un Pokémon");
    return;
  }

  try {
    const json = await postData("/pokemon-xml", text);
    outputElement.value = json.result;
  } catch (error) {
    alert(error.message);
  }
});

btnPokeInfo.addEventListener("click", async () => {
  const text = inputElement.value;

  if (!text || text.trim() === "") {
    alert("Per favor, escriu el nom d'un Pokémon");
    return;
  }

  try {
    const pokemon = await postData("/pokemon-data", text);

    pokemonContainer.innerHTML = "";

    if (pokemon.sprites && pokemon.sprites.front_default) {
      const img = document.createElement("img");
      img.src = pokemon.sprites.front_default;
      img.alt = pokemon.name || "Pokémon";
      img.style.width = "150px";
      pokemonContainer.appendChild(img);
    }

    const nameP = document.createElement("p");
    nameP.textContent = "Nom: " + (pokemon.name || "No disponible");
    pokemonContainer.appendChild(nameP);

    if (pokemon.abilities && pokemon.abilities.length > 0) {
      const abilitiesTitle = document.createElement("p");
      abilitiesTitle.textContent = "Habilitats:";
      abilitiesTitle.style.fontWeight = "bold";
      pokemonContainer.appendChild(abilitiesTitle);

      const abilitiesList = document.createElement("ul");
      pokemon.abilities.forEach((ability) => {
        const li = document.createElement("li");
        li.textContent = ability.ability.name;
        abilitiesList.appendChild(li);
      });
      pokemonContainer.appendChild(abilitiesList);
    }
  } catch (error) {
    alert(error.message);
  }
});