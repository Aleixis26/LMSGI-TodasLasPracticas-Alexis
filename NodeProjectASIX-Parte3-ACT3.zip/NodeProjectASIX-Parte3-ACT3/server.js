const path = require("path");
const express = require("express");
const convert = require("xml-js");

const app = express();
const PORT = process.env.PORT || 3000;

// permet rebre JSON i dades de formulari
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// servir fitxers estàtics (HTML, JS, CSS)
app.use(express.static(path.join(__dirname, "public")));

// endpoint d'exemple
app.post("/convert", (req, res) => {
  const { data } = req.body;

  if (typeof data !== "string") {
    return res.status(400).json({ error: "Dades no vàlides" });
  }

  const result = data.toUpperCase();
  res.json({ result });
});

//=================funció manual corregida===========================================
app.post("/convertTOXMl", (req, res) => {
  const { data } = req.body;

  if (typeof data !== "string" || data.trim() === "") {
    return res.status(400).json({ error: "Dades no vàlides per a la conversió a XML" });
  }

  const input = data.trim();

  // Intentem parsejar com a JSON per crear XML amb un arrel clar
  try {
    const jsonObject = JSON.parse(input);
    const xml = convert.js2xml({ arrel: jsonObject }, { compact: true, spaces: 4 });
    return res.json({ result: xml });
  } catch (e) {
    // Si no és JSON vàlid, fem una conversió manual simple
    let textRebut = input.replace(/^{|}$/g, "").replace(/"/g, "");
    const parts = textRebut.split(",").map((part) => part.trim()).filter(Boolean);

    const xmlParts = parts.map((part) => {
      const [key, ...rest] = part.split(":");
      if (!key || rest.length === 0) return "";
      const value = rest.join(":").trim();
      const tag = key.trim();
      return `<${tag}>${value}</${tag}>`;
    }).filter(Boolean);

    const xml = `<arrel>${xmlParts.join("")}</arrel>`;
    return res.json({ result: xml });
  }
});

//=================Funcions amb LLIBRERIA===========================================
app.post("/xml-to-json", (req, res) => {
  const { data } = req.body;

  if (typeof data !== "string" || data.trim() === "") {
    return res.status(400).json({ error: "Dades XML no vàlides" });
  }

  try {
    const result = convert.xml2json(data, { compact: true, spaces: 4 });
    res.json({ result });
  } catch (error) {
    res.status(400).json({ error: "Error en la conversió XML -> JSON" });
  }
});

app.post("/json-to-xml", (req, res) => {
  const { data } = req.body;

  if (data === undefined || data === null) {
    return res.status(400).json({ error: "Dades JSON no vàlides" });
  }

  try {
    const jsonObject = typeof data === "string" ? JSON.parse(data) : data;
    const result = convert.js2xml({ arrel: jsonObject }, { compact: true, spaces: 4 });
    res.json({ result });
  } catch (error) {
    res.status(400).json({ error: "Error en la conversió JSON -> XML" });
  }
});

//=================Rutes de PokeAPI===========================================
// Funció per buscar Pokémon a la PokeAPI
async function fetchPokemonData(pokemonName) {
  const pokemonUrl = `https://pokeapi.co/api/v2/pokemon/${pokemonName}`;
  const response = await fetch(pokemonUrl);

  if (!response.ok) {
    const error = new Error("Pokémon no trobat");
    error.status = 404;
    throw error;
  }

  return response.json();
}

// Aquesta ruta retorna l'XML del Pokémon
app.post("/pokemon-xml", async (req, res) => {
  const { data } = req.body;

  if (!data || data.trim() === "") {
    return res.status(400).json({ error: "Nom del Pokémon no pot estar buit" });
  }

  const pokemonName = data.trim().toLowerCase();

  try {
    const pokemonData = await fetchPokemonData(pokemonName);
    const result = convert.js2xml({ arrel: pokemonData }, { compact: true, spaces: 4 });
    res.json({ result });
  } catch (error) {
    if (error.status === 404) {
      return res.status(404).json({ error: "Pokémon no trobat" });
    }
    res.status(500).json({ error: "Error en la cerca" });
  }
});

// Aquesta ruta retorna el JSON natiu del Pokémon
app.post("/pokemon-data", async (req, res) => {
  const { data } = req.body;

  if (!data || data.trim() === "") {
    return res.status(400).json({ error: "Nom del Pokémon no pot estar buit" });
  }

  const pokemonName = data.trim().toLowerCase();

  try {
    const pokemonData = await fetchPokemonData(pokemonName);
    res.json(pokemonData);
  } catch (error) {
    if (error.status === 404) {
      return res.status(404).json({ error: "Pokémon no trobat" });
    }
    res.status(500).json({ error: "Error en la cerca" });
  }
});

app.listen(PORT, () => {
  console.log(`Servidor a http://localhost:${PORT}`);
});